/*****************************
Query the University Database
*****************************/
import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.lang.String;
import java.util.Scanner;

public class MyQuery {

    private Connection conn = null;
	 private Statement statement = null;
	 private ResultSet resultSet = null;
    
    public MyQuery(Connection c)throws SQLException
    {
        conn = c;
        // Statements allow to issue SQL queries to the database
        statement = conn.createStatement();
    }
    
    public void findFall2009Students() throws SQLException
    {
        String query  = "select distinct name from student natural join takes where semester = \'Fall\' and year = 2009;";

        resultSet = statement.executeQuery(query);
    }
    
    public void printFall2009Students() throws IOException, SQLException
    {
	      System.out.println("******** Query 0 ********");
         System.out.println("name");
         while (resultSet.next()) {
			// It is possible to get the columns via name
			// also possible to get the columns via the column number which starts at 1
			String name = resultSet.getString(1);
         System.out.println(name);
   		}        
    }

    public void findGPAInfo() throws SQLException
    {

    	String makeTempTable = "create temporary table withGradeAsNum (" +
			    "  `ID` varchar(5) NOT NULL DEFAULT ''," +
			    "  `course_id` varchar(8) NOT NULL DEFAULT ''," +
			    "  `sec_id` varchar(8) NOT NULL DEFAULT ''," +
			    "  `semester` varchar(6) NOT NULL DEFAULT ''," +
			    "  `year` decimal(4,0) NOT NULL DEFAULT '0'," +
			    "  `grade` varchar(4) DEFAULT NULL);";
    	String insertValues = "insert into withGradeAsNum (select * from takes);";
    	String changeToNum1 = "update withGradeAsNum set grade=case when grade='A' then '4.0'\n" +
			    " when grade='A-' then '3.67' when grade='B+' then '3.33' when grade='B' then '3.0'" +
			    " when grade='B-' then '2.67' when grade='C+' then '2.33' when grade='C' then '2.0'" +
			    " when grade='C-' then '1.67' when grade='D+' then '1.33' when grade='D' then '1.0'" +
			    " when grade='D-' then '0.67' when grade='F' then '0.0' else null end;";
    	String changeToNum2 = "alter table withGradeAsNum modify column grade double;";
    	String query = "select ID, name, round(sum(grade * credits)/sum(credits), 6) GPA from course natural join withGradeAsNum"
			    + " natural join student group by ID";
    	statement.execute(makeTempTable);
    	statement.execute(insertValues);
    	statement.executeUpdate(changeToNum1);
    	statement.execute(changeToNum2);
    	resultSet = statement.executeQuery(query);

    }
    
    public void printGPAInfo() throws IOException, SQLException
    {
		   System.out.println("******** Query 1 ********");
		   System.out.printf("%-12s%-12s%-12s\n", "id", "name", "GPA");
		   while (resultSet.next()) {
		   	String id = resultSet.getString(1);
		   	String name = resultSet.getString(2);
		   	String gpa = resultSet.getString(3);
		   	System.out.printf("%-12s%-12s%-12s\n", id, name, gpa);
		   }

    }

    public void findMorningCourses() throws SQLException
    {

    	String getOutput = "SELECT course_id, sec_id, title, semester, year, name, (SELECT count(course_id) FROM takes WHERE\n" +
                "course_id=sub.course_id AND sec_id=sub.sec_id AND semester=sub.semester AND year=sub.year) enrollment\n" +
                "FROM instructor NATURAL JOIN teaches NATURAL JOIN (SELECT course_id, sec_id, semester, year\n" +
                "FROM (SELECT DISTINCT course_id, sec_id, semester, year\n" +
                "FROM section NATURAL JOIN time_slot WHERE start_hr<=12) a1 NATURAL LEFT JOIN\n" +
                "(SELECT * FROM (SELECT DISTINCT course_id, sec_id, semester, year\n" +
                "FROM section NATURAL JOIN time_slot WHERE start_hr<=12) a NATURAL LEFT JOIN takes b\n" +
                "WHERE b.course_id IS NULL) b1 WHERE b1.course_id IS NULL) sub NATURAL JOIN course;";
    	resultSet = statement.executeQuery(getOutput);

    }

    public void printMorningCourses() throws IOException, SQLException
    {
	   	System.out.println("******** Query 2 ********");
        System.out.printf("%-12s%-12s%-32s%-12s%-12s%-12s%-12s\n", "course_id", "sec_id", "title",
                "semester", "year", "name", "enrollment");
        while (resultSet.next()) {
            String a = resultSet.getString(1);
            String b = resultSet.getString(2);
            String c = resultSet.getString(3);
            String d = resultSet.getString(4);
            String e = resultSet.getString(5);
            String f = resultSet.getString(6);
            String g = resultSet.getString(7);
            System.out.printf("%-12s%-12s%-32s%-12s%-12s%-16s%-12s\n", a, b, c, d, e, f, g);
        }

    }

    public void findBusyInstructor() throws SQLException
    {

        String getOutput = "SELECT name\n" +
                "FROM instructor NATURAL JOIN teaches GROUP BY ID HAVING " +
                "count(ID) >= ALL (SELECT count(ID) FROM teaches GROUP BY ID);";
        resultSet = statement.executeQuery(getOutput);

    }

    public void printBusyInstructor() throws IOException, SQLException
    {
		   System.out.println("******** Query 3 ********");
		   System.out.println("name");
		   while (resultSet.next()) {
		       System.out.println(resultSet.getString(1));
           }

    }

    public void findPrereq() throws SQLException
    {

        String q1 = "CREATE TEMPORARY TABLE prereq1 SELECT prereq.course_id, prereq_id, title " +
                "FROM prereq, course WHERE (course.course_id = prereq.prereq_id);";
        String q2 = "SELECT course.title, prereq1.title FROM course LEFT OUTER JOIN prereq1 " +
                "ON (course.course_id = prereq1.course_id);";
        statement.executeUpdate(q1);
        resultSet = statement.executeQuery(q2);

    }

    public void printPrereq() throws IOException, SQLException
    {
		   System.out.println("******** Query 4 ********");
		   System.out.printf("%-32s%-32s\n", "course", "prereq");
		   while (resultSet.next()) {

		       String course = resultSet.getString(1);
		       String prereq = resultSet.getString(2);
		       System.out.printf("%-32s%-32s\n", course, prereq);

           }

    }

    public void updateTable() throws SQLException
    {

        String makeTempTable = "CREATE TEMPORARY TABLE IF NOT EXISTS tempStudent SELECT * FROM student;";
        String update = "UPDATE tempStudent AS s1 SET tot_cred = (SELECT sum(credits)\n" +
                " FROM takes NATURAL JOIN course WHERE grade IS NOT NULL AND grade <> 'F' AND ID=s1.ID);";
        String getOutput = "SELECT *\n" +
                "FROM tempStudent;";
        statement.executeUpdate(makeTempTable);
        statement.executeUpdate(update);
        resultSet = statement.executeQuery(getOutput);

    }

    public void printUpdatedTable() throws IOException, SQLException
    {
		   System.out.println("******** Query 5 ********");
		   System.out.printf("%-12s%-12s%-12s%-12s\n", "ID", "name", "dept_name", "tot_cred");
		   while (resultSet.next()) {
		       String a = resultSet.getString(1);
               String b = resultSet.getString(2);
               String c = resultSet.getString(3);
               String d = resultSet.getString(4);
               if(d == null) { d = "0"; }
               System.out.printf("%-12s%-12s%-12s%-12s\n", a, b, c, d);
           }

    }

    public void findFirstLastSemester() throws SQLException
    {

        String q1 = "DROP TABLE tempStudent";
        String q2 = "CREATE TEMPORARY TABLE student1 SELECT takes.ID, " +
                "name, year, semester FROM takes LEFT OUTER JOIN student " +
                "ON (takes.ID = student.ID);";
        String q3 = "ALTER TABLE student1 ADD COLUMN date FLOAT(5);";
        String q4 = "UPDATE student1 SET date = CASE WHEN semester = 'Winter'" +
                "THEN YEAR + .1 WHEN semester = 'Spring' THEN YEAR + .2" +
                "WHEN semester = 'Summer' THEN YEAR + .3 WHEN semester = 'Fall'" +
                "THEN YEAR + .4 END;";
        String q5 = "ALTER TABLE student1 ADD COLUMN semester_name VARCHAR(11);";
        String q6 = "CREATE TEMPORARY TABLE student2 SELECT * FROM student1;";
        String q7 = "CREATE TEMPORARY TABLE studentMin SELECT s1.ID," +
                "CONCAT(semester, ' ', YEAR) AS First_Semester FROM student1 AS s1 " +
                "INNER JOIN (SELECT student2.ID, min(DATE) AS minDate FROM student2 " +
                "GROUP BY student2.ID) AS s2 ON s1.id = s2.ID AND s1.date = s2.MinDate;";
        String q8 = "CREATE TEMPORARY TABLE studentMax SELECT s1.ID," +
                "CONCAT(semester, ' ', YEAR) AS Last_Semester FROM student1 AS s1 " +
                "INNER JOIN (SELECT student2.ID, max(DATE) AS maxDate FROM student2 " +
                "GROUP BY student2.ID) AS s2 ON s1.ID = s2.ID AND s1.date = s2.MaxDate;";
        String q9 = "SELECT DISTINCT id, name, First_Semester, Last_Semester " +
                "FROM student1 NATURAL JOIN studentMin NATURAL JOIN studentMax;";
        statement.executeUpdate(q1);
        statement.executeUpdate(q2);
        statement.executeUpdate(q3);
        statement.executeUpdate(q4);
        statement.executeUpdate(q5);
        statement.executeUpdate(q6);
        statement.executeUpdate(q7);
        statement.executeUpdate(q8);
        resultSet = statement.executeQuery(q9);

    }

    public void printFirstLastSemester() throws IOException, SQLException
    {
        System.out.println("******** Query 6 ********");
        System.out.printf("%-16s%-16s%-16s%-16s\n", "id", "name", "First_Semester", "Last_Semester");
        while (resultSet.next()) {
            String a = resultSet.getString(1);
            String b = resultSet.getString(2);
            String c = resultSet.getString(3);
            String d = resultSet.getString(4);
            System.out.printf("%-16s%-16s%-16s%-16s\n", a, b, c, d);
        }

    }
	
	public void findHeadCounts() throws SQLException
	{
		   System.out.println("******** Query 7 ********");
		   String q0 = "DROP PROCEDURE getNumbers";
		   statement.executeUpdate(q0);
		   String q1 = "CREATE PROCEDURE getNumbers(IN dept VARCHAR(50), OUT out1 INT, OUT out2 INT) " +
                   "BEGIN SELECT count(DISTINCT ID) INTO out1 FROM instructor WHERE dept_name = dept; " +
                   "SELECT count(DISTINCT ID) INTO out2 FROM student WHERE dept_name = dept; END;";
		   statement.executeUpdate(q1);
		   Scanner kb = new Scanner(System.in);
		   System.out.print("Please enter the department name for the query: ");
		   String s = kb.nextLine();
		   CallableStatement cs = conn.prepareCall("{CALL getNumbers(?,?,?)}");
		   cs.setString(1, s);
		   cs.registerOutParameter(2, java.sql.Types.INTEGER);
		   cs.registerOutParameter(3, java.sql.Types.INTEGER);
		   cs.executeUpdate();
		   int instructors = cs.getInt(2);
		   int students = cs.getInt(3);
		   System.out.println(s);
		   System.out.println(s + " Department has " + instructors + " instructors");
		   System.out.println(s + " Department has " + students + " students");
	}
}
