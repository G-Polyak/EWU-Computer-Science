//George Polyak
//Prog7
//CSCD300

public interface Map {

    int size();
    String get(int id);
    void put(int id, String value);
    String remove(int id);

}
