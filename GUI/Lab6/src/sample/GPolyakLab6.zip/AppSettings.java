package sample;

public class AppSettings {

	public static boolean mDateOrString = false;
	public static boolean mItalics = false;
	public static boolean mBold = false;
	public static String mUserString = "";
	public static int mFontSize = 16;

}
