//George Polyak
//Prog4
//CSCD300

interface StringStack {

    boolean isEmpty();
    String peek();
    String pop();
    void push(String element);
    int size();

}
